export class AppUser {
  userName: string = "";
  password: string = "";
}