map-01 - Directions from address to address
  Added button that calls getDirections() method
map-02 - Directions from lat/lng to lat/lng
  Modified getDirections() method to use lat/lng
map-03 - Add text directions
  Modified getDirections() method to call directionsRenderer.setPanel()
map-04 - Direction service options
  Modified getDirections() method to add some options
    avoidHighways: true,
    provideRouteAlternatives: true