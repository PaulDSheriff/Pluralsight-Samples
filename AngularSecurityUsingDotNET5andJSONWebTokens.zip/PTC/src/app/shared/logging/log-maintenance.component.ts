import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ptc-log-maintenance',
  templateUrl: './log-maintenance.component.html',
  styleUrls: ['./log-maintenance.component.css']
})
export class LogMaintenanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
