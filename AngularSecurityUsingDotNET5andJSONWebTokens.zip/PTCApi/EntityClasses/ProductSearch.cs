namespace PTCApi.EntityClasses {
  public class ProductSearch {
    public string ProductName { get; set; }
  }
}
