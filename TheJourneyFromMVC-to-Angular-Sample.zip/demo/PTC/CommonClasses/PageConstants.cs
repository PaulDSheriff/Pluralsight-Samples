﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTC
{
  public class PageConstants
  {
    public const string LIST = "List";
    public const string EDIT = "Edit";
    public const string ADD = "Add";
  }
}
