﻿Create the database
-------------------
To create the database and the data for this project, run the \SqlScripts\PTC.SQL in SQL Server

Files of Interest
-----------------
\CommonClasses\PageConstants.cs - UI Constants
\Models\PTCData.edmx - Entity Framework of PTC database tables
\Views\Home\Index.cshtml - The sample Product screen
\ViewModels\PTCViewModel.cs - View Model used by Index page
