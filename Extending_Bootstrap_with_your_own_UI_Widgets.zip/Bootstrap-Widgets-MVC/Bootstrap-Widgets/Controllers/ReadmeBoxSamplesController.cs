﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Bootstrap_Widgets.Controllers
{
  public class ReadmeBoxSamplesController : Controller
  {   
    public ActionResult ReadmeBox01()
    {
      return View();
    }

    public ActionResult ReadmeBox02()
    {
      return View();
    }
  }
}