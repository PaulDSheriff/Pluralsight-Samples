﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Bootstrap_Widgets.Controllers
{
  public class SummaryBlockSamplesController : Controller
  {   
    public ActionResult SummaryBlock01()
    {
      return View();
    }

    public ActionResult SummaryBlock02()
    {
      return View();
    }
  }
}