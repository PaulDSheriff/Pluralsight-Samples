01 - Display address on OpenStreetMaps
02 - Display address on Google Maps
03 - Redirect to map.html
map.html - Embed OpenLayers map right on the page, display a point on the map