﻿To run this project in Visual Studio 2019, open the LINQSample.sln
To run this project in Visual Studio Code, open the folder \LINQSamples

SampleViewModel Samples
--------------------------------------------------
ForEach() - ForEach allows you to iterate over a collection to perform assignments within each object.
ForEachCallingMethod() - Iterate over each object in the collection and call a method to set a property
Take() - Use Take() to select a specified number of items from the beginning of a collection
TakeWhile() - Use TakeWhile() to select a specified number of items from the beginning of a collection based on a true condition
Skip() - Use Skip() to move past a specified number of items from the beginning of a collection
SkipWhile() - Use SkipWhile() to move past a specified number of items from the beginning of a collection based on a true condition
Distinct() - The Distinct() operator finds all unique values within a collection
DistinctUsingGroupByFirstOrDefault() - The Distinct() operator can be simulated using the GroupBy() and FirstOrDefault() operators