﻿To run this project in Visual Studio 2019, open the LINQSample.sln
To run this project in Visual Studio Code, open the folder \LINQSamples

SampleViewModel Samples
--------------------------------------------------
GetAllLooping() - Put all products into a collection via looping, no LINQ
GetAll() - Put all products into a collection using LINQ
GetSingleColumn() - Select a single column
GetSpecificColumns() - Select a few specific properties from products and create new Product objects
AnonymousClass() - Create an anonymous class from selected product properties
OrderBy() - Order products by Name
OrderByDescending() - Order products by name in descending order
OrderByTwoFields() - Order products by Color descending, then Name